// If this file fails to be included, in the page,
// it would mean that an adblocker is active;

jQuery.adblock = false;